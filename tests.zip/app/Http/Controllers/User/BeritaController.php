<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BeritaController extends Controller
{
    /**
     * Controller untuk berita user.
     * (Fitur belum diimplementasikan).
     */
}
