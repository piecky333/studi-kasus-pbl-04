<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

/**
 * Class PengurusController
 * 
 * Controller ini ditujukan untuk mengelola data Pengurus.
 * 
 * @todo Implementasi fitur CRUD untuk Pengurus belum tersedia.
 * @package App\Http\Controllers\Admin
 */
class PengurusController extends Controller
{
    // Belum ada implementasi method.
}
