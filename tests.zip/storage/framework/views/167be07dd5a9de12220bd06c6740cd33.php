<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4 sm:p-6 lg:p-8">
        <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl overflow-hidden rounded-lg p-6">
                
                
                
                
                <nav class="text-sm font-medium text-gray-500 mb-2" aria-label="Breadcrumb">
                    <ol class="list-none p-0 inline-flex">
                        <li class="flex items-center">
                            <a href="<?php echo e(route('admin.spk.index')); ?>" class="text-gray-500 hover:text-gray-700">
                                Daftar Keputusan SPK
                            </a>
                            <svg class="flex-shrink-0 mx-2 h-4 w-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10l-3.293-3.293a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" /></svg>
                        </li>
                        <li class="flex items-center">
                            <a href="<?php echo e(route('admin.spk.kriteria.index', $idKeputusan)); ?>" class="text-gray-500 hover:text-gray-700">Daftar Kriteria</a>
                        </li><svg class="flex-shrink-0 mx-2 h-4 w-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10l-3.293-3.293a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" /></svg>
                        
                        <li class="flex items-center">
                            <span class="text-indigo-600 font-semibold">Bobot Preferensi AHP</span>
                        </li>
                    </ol>
                </nav>
                
                
                
                <?php if(session('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-sm" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <div class="bg-white rounded-lg p-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4 border-b pb-2">Perbandingan Data Antar Kriteria (AHP)</h2>
                    <p class="text-gray-600 mb-6">Silakan bandingkan setiap pasangan kriteria menggunakan skala Saaty (1-9).</p>

                    
                    <form id="ahp-form" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_keputusan" value="<?php echo e($idKeputusan ?? ''); ?>">

                        
                        <div class="overflow-x-auto border rounded-lg p-4 bg-gray-50">
                            <h4 class="font-semibold text-gray-700 mb-3">Input Perbandingan Pasangan</h4>
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-3 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider w-1/4">Kriteria A</th>
                                        <th class="px-3 py-3 text-center text-sm font-semibold text-gray-700 uppercase tracking-wider w-1/2">Skala Perbandingan (1-9)</th>
                                        <th class="px-3 py-3 text-right text-sm font-semibold text-gray-700 uppercase tracking-wider w-1/4">Kriteria B</th>
                                    </tr>
                                </thead>
                                
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $pasangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td class="px-3 py-4 whitespace-nowrap align-top text-sm font-medium text-gray-900">
                                                (<?php echo e($p['kriteria1']->kode_kriteria); ?>) <?php echo e($p['kriteria1']->nama_kriteria); ?>

                                                <input type="hidden" name="pasangan[<?php echo e($p['kriteria1']->id_kriteria); ?>_<?php echo e($p['kriteria2']->id_kriteria); ?>][kriteria1_id]" value="<?php echo e($p['kriteria1']->id_kriteria); ?>">
                                                <input type="hidden" name="pasangan[<?php echo e($p['kriteria1']->id_kriteria); ?>_<?php echo e($p['kriteria2']->id_kriteria); ?>][kriteria2_id]" value="<?php echo e($p['kriteria2']->id_kriteria); ?>">
                                            </td>

                                            
                                            <td class="px-3 py-4 align-top text-center text-sm text-gray-500">
                                                <?php
                                                    $keyPasangan = "{$p['kriteria1']->id_kriteria}_{$p['kriteria2']->id_kriteria}";
                                                    $inputName = "pasangan[{$keyPasangan}][nilai]";

                                                    // Prioritaskan nilai dari old input (jika ada withInput()), jika tidak ada, ambil dari DB/pasangan (yang sudah tersimpan)
                                                    $nilaiTersimpan = old("pasangan.{$keyPasangan}.nilai", $p['nilai_perbandingan_tersimpan'] ?? 1);
                                                ?>

                                                <div class="flex justify-center items-center space-x-0.5">
                                                    
                                                    <div class="inline-flex">
                                                        <?php for($i = 9; $i >= 2; $i--): ?>
                                                            <?php
                                                                $isChecked = $nilaiTersimpan == $i;
                                                            ?>
                                                            <label class="relative group" title="Skala <?php echo e($i); ?>: A lebih penting dari B">
                                                                <input type="radio" name="<?php echo e($inputName); ?>" value="<?php echo e($i); ?>"
                                                                    class="hidden peer" <?php echo e($isChecked ? 'checked' : ''); ?> required>
                                                                <span
                                                                    class="px-2 py-1 text-xs font-semibold border border-green-400 text-green-700 bg-green-50 hover:bg-green-200 transition duration-150 ease-in-out cursor-pointer 
                                                                    peer-checked:bg-green-700 peer-checked:text-white peer-checked:border-green-700 
                                                                    <?php echo e($i == 9 ? 'rounded-l-lg' : ''); ?> border-r-0">
                                                                    <?php echo e($i); ?>

                                                                </span>
                                                            </label>
                                                        <?php endfor; ?>
                                                    </div>

                                                    
                                                    <label class="relative group" title="Skala 1: A dan B Sama Penting">
                                                        <input type="radio" name="<?php echo e($inputName); ?>" value="1" class="hidden peer"
                                                            <?php echo e($nilaiTersimpan == 1 ? 'checked' : ''); ?> required>
                                                        <span
                                                            class="px-2 py-1 text-xs font-semibold border border-blue-400 text-blue-700 bg-blue-50 hover:bg-blue-200 transition duration-150 ease-in-out cursor-pointer 
                                                            peer-checked:bg-blue-700 peer-checked:text-white peer-checked:border-blue-700">
                                                            1
                                                        </span>
                                                    </label>

                                                    
                                                    <div class="inline-flex">
                                                        <?php for($i = 2; $i <= 9; $i++): ?>
                                                            <?php
                                                                $valueKanan = -$i; // Nilai Negatif untuk Kriteria Kanan
                                                                $isChecked = $nilaiTersimpan == $valueKanan;
                                                            ?>
                                                            <label class="relative group" title="Skala 1/<?php echo e($i); ?>: B lebih penting dari A">
                                                                <input type="radio" name="<?php echo e($inputName); ?>" value="<?php echo e($valueKanan); ?>"
                                                                    class="hidden peer" <?php echo e($isChecked ? 'checked' : ''); ?> required>
                                                                <span
                                                                    class="px-2 py-1 text-xs font-semibold border border-red-400 text-red-700 bg-red-50 hover:bg-red-200 transition duration-150 ease-in-out cursor-pointer 
                                                                    peer-checked:bg-red-700 peer-checked:text-white peer-checked:border-red-700 
                                                                    <?php echo e($i == 9 ? 'rounded-r-lg' : ''); ?> border-l-0">
                                                                    <?php echo e($i); ?>

                                                                </span>
                                                            </label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                            </td>

                                            
                                            <td
                                                class="px-3 py-4 whitespace-nowrap align-top text-sm font-medium text-gray-900 text-right">
                                                (<?php echo e($p['kriteria2']->kode_kriteria); ?>) <?php echo e($p['kriteria2']->nama_kriteria); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="flex justify-center space-x-4 mt-8">
                            
                            <button type="submit" formaction="<?php echo e(route('admin.spk.kriteria.perbandingan.simpan', $idKeputusan)); ?>"
                                class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 shadow-md inline-flex items-center">
                                <i class="fas fa-save mr-2"></i> Simpan
                            </button>

                            
                            <button type="submit" formaction="<?php echo e(route('admin.spk.kriteria.perbandingan.cek_konsistensi', $idKeputusan)); ?>"
                                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 shadow-md inline-flex items-center">
                                <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                Cek Konsistensi
                            </button>
                        </div>
                    </form>
                </div>

                
                <?php if(isset($hasilAHP)): ?>
                    <div
                        class="mt-10 bg-white rounded-lg p-6 border-t-4 <?php if($hasilAHP['crData']['cr'] <= 0.1): ?> border-green-500 <?php else: ?> border-red-500 <?php endif; ?>">
                        <h3 class="text-xl font-bold text-gray-800 mb-4">Hasil Perhitungan AHP dan Konsistensi</h3>

                        <h2><b>Ringkasan Perhitungan AHP</b></h2>
                        <br>
                        
                        <div
                            class="mb-6 p-4 rounded-lg <?php if($hasilAHP['crData']['cr'] <= 0.1): ?> bg-green-50 border border-green-300 <?php else: ?> bg-red-50 border border-red-300 <?php endif; ?>">
                            <div class="flex justify-between items-center">
                                <p
                                    class="font-bold text-lg <?php if($hasilAHP['crData']['cr'] <= 0.1): ?> text-green-700 <?php else: ?> text-red-700 <?php endif; ?>">
                                    Consistency Ratio (CR): <span
                                        class="text-2xl"><?php echo e(number_format($hasilAHP['crData']['cr'], 4)); ?></span>
                                    <?php if($hasilAHP['crData']['cr'] <= 0.1): ?>
                                        <span class="ml-2 text-sm font-normal text-green-600">(KONSISTEN, CR &le; 0.10)</span>
                                    <?php else: ?>
                                        <span class="ml-2 text-sm font-normal text-red-600">(TIDAK KONSISTEN, CR > 0.10)</span>
                                    <?php endif; ?>
                                </p>
                                <?php if($hasilAHP['crData']['cr'] <= 0.1): ?>
                                    <a href="<?php echo e(route('admin.spk.hasil.index', $idKeputusan)); ?>"
                                        class="inline-flex items-center bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 shadow-sm text-sm">
                                        <i class="fas fa-play mr-2"></i> Lanjutkan ke Proses SAW
                                    </a>
                                <?php endif; ?>
                            </div>
                            

                            
                            <div class="mt-2 text-sm space-y-1">
                                <p><strong>CI (Consistency Index):</strong> <span class="font-mono"><?php echo e(number_format($hasilAHP['crData']['ci'], 4)); ?></span></p>
                                <p><strong>RI (Random Index, n=<?php echo e($hasilAHP['n']); ?>):</strong> <span class="font-mono"><?php echo e(number_format($hasilAHP['crData']['ri'], 4)); ?></span></p>
                            </div>

                            <?php if($hasilAHP['crData']['cr'] > 0.1): ?>
                                <p class="text-sm mt-1 text-red-600 font-semibold">
                                    **TINJAU ULANG:** Harap perbaiki nilai perbandingan Anda di atas hingga CR &le; 0.10.
                                </p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="p-4 bg-gray-50 rounded-lg shadow-inner mb-6">
                            <h4 class="font-semibold text-gray-700 mb-3">Prioritas Bobot Akhir Kriteria (Eigen Vector)</h4>
                            <div class="flex flex-wrap gap-4 justify-center">
                                <?php $__currentLoopData = $kriteriaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-3 bg-white rounded-md shadow-sm border border-blue-200 min-w-[120px] text-center">
                                        <p class="text-sm font-medium text-blue-600"><?php echo e($kriteria->kode_kriteria); ?></p>
                                        <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($hasilAHP['weights'][$i], 4)); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <br>
                            <p class="text-center text-xs text-gray-500 mt-2">Total Bobot: <?php echo e(number_format(array_sum($hasilAHP['weights'] ?? [0]), 4)); ?></p>
                        </div>
                        <br>

                        <h2><b>Matriks Perbandingan Berpasangan</b></h2>
                        <p class="text-sm text-gray-600 mb-3">Matriks ini dibuat dari input perbandingan Anda Input dari skala perbandingan.</p>
                        <div class="overflow-x-auto border rounded-lg mb-6">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider border-r">
                                            Kriteria</th>
                                        <?php $__currentLoopData = $kriteriaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider text-center">
                                                <?php echo e($kriteria->kode_kriteria); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $hasilAHP['matrix']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td class="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900 bg-gray-50 border-r">
                                                <?php if(isset($kriteriaList[$row_index])): ?>
                                                    <?php echo e($kriteriaList[$row_index]->kode_kriteria); ?>

                                                <?php else: ?>
                                                    
                                                    <span class="text-red-600 font-bold">Kriteria HILANG (#<?php echo e($row_index + 1); ?>)</span>
                                                <?php endif; ?>
                                            </td>
                                            
                                            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col_index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td
                                                    class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono <?php if($row_index == $col_index): ?> bg-gray-200 font-bold <?php endif; ?>">
                                                    <?php echo e(number_format($value, 4)); ?>

                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td class="px-3 py-2 text-xs font-bold text-gray-600 bg-gray-100 border-r">Total Kolom</td>
                                        <?php $__currentLoopData = $hasilAHP['col_sum']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="px-3 py-2 text-xs font-bold text-gray-700 bg-gray-100 text-center">
                                                <?php echo e(number_format($sum, 4)); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <br>

                        <h2> <b>Matriks Normalisasi (Vektor Prioritas)</b> </h2>
                        <p class="text-sm text-gray-600 mb-3">Nilai di dalamnya didapatkan dari pembagian elemen matriks input dengan Total Kolom yang sesuai. Rata-rata dari nilai-nilai setiap baris inilah yang menghasilkan Bobot Prioritas.</p>
                        <div class="overflow-x-auto border rounded-lg mb-6">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider border-r">Kriteria</th>
                                        <?php $__currentLoopData = $kriteriaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider text-center"><?php echo e($kriteria->kode_kriteria); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th
                                            class="px-3 py-2 text-xs font-bold text-gray-700 uppercase tracking-wider text-center bg-blue-100 border-l">
                                            Bobot Prioritas / Rata-rata Baris (WP)</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $hasilAHP['normalized_matrix']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900 bg-gray-50 border-r">
                                                <?php if(isset($kriteriaList[$row_index])): ?>
                                                    <?php echo e($kriteriaList[$row_index]->kode_kriteria); ?>

                                                <?php else: ?>
                                                    <span class="text-red-600 font-bold">Kriteria HILANG (#<?php echo e($row_index + 1); ?>)</span>
                                                <?php endif; ?>
                                            </td>
                                            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col_index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono">
                                                    <?php echo e(number_format($value, 4)); ?>

                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td
                                                class="px-3 py-2 whitespace-nowrap text-sm text-center font-bold font-mono bg-blue-100 border-l">
                                                <?php echo e(number_format($hasilAHP['weights'][$row_index], 4)); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <br>

                        <h2><b>Perhitungan Lambda Maksimum dan Vektor Prioritas</b> </h2>
                        <p class="text-sm text-gray-600 mb-3">perhitungan nilai Lambda Maksimum, vektor Prioritas, dan Vektor Konsistensi sebagai dasar untuk menghitung Consistency Index (CI) dan Consistency Ratio (CR). </p>

                        <div class="overflow-x-auto border rounded-lg mb-6">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider border-r">Kriteria</th>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider text-center">Eigen Vector</th>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider text-center">Vektor Jumlah Tertimbang</th>
                                        <th class="px-3 py-2 text-xs font-medium text-gray-600 uppercase tracking-wider text-center">Vektor Konsistensi Rasio</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $kriteriaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900 bg-gray-50 border-r">
                                                <?php echo e($kriteria->kode_kriteria); ?></td>
                                            <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono"><?php echo e(number_format($hasilAHP['weights'][$i], 4)); ?></td>
                                            <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono"><?php echo e(number_format($hasilAHP['weighted_sum'][$i], 4)); ?></td>
                                            <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono"><?php echo e(number_format($hasilAHP['ratio_vector'][$i], 4)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr>
                                        <td colspan="3"
                                            class="px-3 py-2 text-xs font-bold text-right text-gray-700 bg-gray-100 border-r">Total
                                            Vektor Rasio</td>
                                        <td class="px-3 py-2 text-xs font-bold text-gray-700 bg-gray-100 text-center">
                                            <?php echo e(number_format(array_sum($hasilAHP['ratio_vector']), 4)); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td colspan="3"
                                            class="px-3 py-2 text-xs font-bold text-right text-gray-700 bg-gray-100 border-r">
                                            Lambda Maksimum
                                        </td>
                                        <td class="px-3 py-2 text-xs font-bold text-gray-700 bg-gray-100 text-center bg-yellow-100">
                                            <?php echo e(number_format($hasilAHP['crData']['lambda_max'], 4)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <br>

                        <h2 class="text-gray-700 mb-2"><b>Perhitungan Akhir</b></h2>
                        <div class="p-4 bg-gray-50 rounded-lg shadow-inner">
                            <ul class="space-y-1 text-sm text-gray-600">
                                <li><b>Consistency Index (CI):</b> <br>lambda maximum - n / (n - 1) 
                                    <br>
                                    (<?php echo e(number_format($hasilAHP['crData']['lambda_max'], 4)); ?> - <?php echo e($hasilAHP['n']); ?>) /
                                    (<?php echo e($hasilAHP['n']); ?> - 1) = <?php echo e(number_format($hasilAHP['crData']['ci'], 4)); ?></li>
                                <br>
                                <li><b>Consistency Ratio (CR):</b> <br>CI / RI <br> <?php echo e(number_format($hasilAHP['crData']['ci'], 4)); ?> /
                                    <?php echo e(number_format($hasilAHP['crData']['ri'], 4)); ?> =
                                    <?php echo e(number_format($hasilAHP['crData']['cr'], 4)); ?></li>
                                    <br>
                                    <p>Nilai CR adalah indikator utama validitas bobot kriteria yang dihasilkan, di mana CR < 0.10 menunjukkan Matriks Perbandingan Anda sudah layak digunakan.</p>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\studi_kasus_pbl\resources\views/pages/admin/spk/kriteria/perbandingan/index.blade.php ENDPATH**/ ?>