<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard Mahasiswa')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            
            <?php if(isset($sanksi) && $sanksi->count() > 0): ?>
                <div class="mb-8 rounded-xl border border-red-200 bg-white shadow-sm overflow-hidden">
                    <div class="bg-red-50 px-6 py-4 border-b border-red-100 flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <div class="bg-red-100 text-red-600 p-2 rounded-lg">
                                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                                </svg>
                            </div>
                            <div>
                                <h3 class="text-lg font-bold text-gray-900">Catatan Sanksi Akademik</h3>
                                <p class="text-sm text-red-600 font-medium">Harap perhatikan catatan pelanggaran di bawah ini</p>
                            </div>
                        </div>
                    </div>

                    <div class="p-0">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-gray-100 bg-gray-50/50">
                                    <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Tanggal</th>
                                    <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Jenis Pelanggaran</th>
                                    <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Hukuman</th>
                                    <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Bukti</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php $__currentLoopData = $sanksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="hover:bg-red-50/30 transition-colors duration-150">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-medium">
                                            <?php echo e(\Carbon\Carbon::parse($item->tanggal_sanksi)->format('d M Y')); ?>

                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-800">
                                            <span class="block font-semibold"><?php echo e($item->jenis_sanksi); ?></span>
                                            <span class="text-gray-500 text-xs mt-0.5 block"><?php echo e(Str::limit($item->keterangan, 60)); ?></span>
                                        </td>
                                        <td class="px-6 py-4 text-sm">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                                <?php echo e($item->jenis_hukuman); ?>

                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-right">
                                            <?php if($item->file_pendukung): ?>
                                                <a href="<?php echo e(asset('storage/' . $item->file_pendukung)); ?>" 
                                                   target="_blank" 
                                                   class="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 transition-colors">
                                                    <span>Lihat Bukti</span>
                                                    <svg class="ml-1.5 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                                                </a>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-xs italic">Tidak ada lampiran</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6 text-gray-900 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                    <div>
                        <h2 class="text-2xl font-bold">Selamat Datang, <?php echo e(Auth::user()->nama); ?>!</h2>
                        <p class="mt-2 text-gray-600">
                            Ini adalah halaman utama mahasiswa. Anda dapat melakukan pengajuan sertifikat, melihat status pengaduan, dan berita terbaru.
                        </p>
                    </div>
                    <div>
                        <a href="<?php echo e(route('mahasiswa.sertifikat.index')); ?>" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            Kelola Sertifikat
                        </a>
                    </div>
                </div>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <!-- Total Pengaduan -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 flex items-center space-x-4">
                        <div class="bg-blue-100 text-blue-600 p-3 rounded-full">
                            
                            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75c0-.231-.035-.454-.1-.664M6.75 7.5H18a2.25 2.25 0 012.25 2.25v9a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18V9.75A2.25 2.25 0 015.25 7.5H6.75" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Total Pengaduan</p>
                            <p class="text-3xl font-bold text-gray-900">
                                <?php echo e($totalPengaduan ?? 0); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <!-- Pengaduan Diproses -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 flex items-center space-x-4">
                        <div class="bg-yellow-100 text-yellow-600 p-3 rounded-full">
                            
                            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Pengaduan Diproses</p>
                            <p class="text-3xl font-bold text-gray-900">
                                <?php echo e($pengaduanDiproses ?? 0); ?>

                            </p>
                        </div>
                    </div>
                </div>

                <!-- Pengaduan Selesai -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 flex items-center space-x-4">
                        <div class="bg-green-100 text-green-600 p-3 rounded-full">
                            
                            <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">Pengaduan Selesai</p>
                            <p class="text-3xl font-bold text-gray-900">
                                <?php echo e($pengaduanSelesai ?? 0); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- Pengaduan List -->
                <div class="lg:col-span-2 bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-900">Pengaduan Terakhir Anda</h3>
                        <a href="<?php echo e(route('mahasiswa.pengaduan.create')); ?>"
                            class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700">
                            Buat Pengaduan Baru
                        </a>
                    </div>

                    <div class="p-6">
                        <?php if($pengaduan->isEmpty()): ?>
                            <p class="text-gray-500">Anda belum membuat pengaduan.</p>
                        <?php else: ?>
                            <div class="overflow-x-auto">   
                            <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-blue-100">
                                        <tr>
                                            <th scope="col"
                                                class="px-6 py-3 text-left text-xs font-semibold text-blue-700 uppercase tracking-wider">
                                                Judul</th>
                                            <th scope="col"
                                                class="px-6 py-3 text-left text-xs font-semibold text-blue-700 uppercase tracking-wider">
                                                Status</th>
                                            <th scope="col"
                                                class="px-6 py-3 text-left text-xs font-semibold text-blue-700 uppercase tracking-wider">
                                                Tanggal</th>
                                            <th scope="col" class="relative px-6 py-3"><span class="sr-only">Aksi</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                    <?php echo e(Str::limit($item->judul, 40)); ?>

                                                </td>

                                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                    <?php
                                                        $statusBersih = trim($item->status);
                                                    ?>

                                                    <?php if(strcasecmp($statusBersih, 'Diproses') == 0): ?>
                                                        <span
                                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">Diproses</span>
                                                    <?php elseif(strcasecmp($statusBersih, 'Selesai') == 0): ?>
                                                        <span
                                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Selesai</span>
                                                    <?php elseif(strcasecmp($statusBersih, 'Ditolak') == 0): ?>
                                                        <span
                                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Ditolak</span>
                                                    <?php elseif(strcasecmp($statusBersih, 'Terkirim') == 0): ?>
                                                        <span
                                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">Terkirim</span>
                                                    <?php else: ?>
                                                        <span
                                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800"><?php echo e($statusBersih ?: 'N/A'); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?php echo e($item->created_at->format('d M Y')); ?>

                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                    <?php
                                                        // Cek apakah ada balasan terakhir dari admin
                                                        // Note: Assuming 'tanggapan' relationship exists in Pengaduan model
                                                        $lastTanggapan = $item->tanggapan ? $item->tanggapan->sortBy('created_at')->last() : null;
                                                        $hasReply = $lastTanggapan && $lastTanggapan->id_admin;
                                                    ?>
                                                    <a href="<?php echo e(route('mahasiswa.pengaduan.show', $item->id_pengaduan)); ?>"
                                                        class="text-indigo-600 hover:text-indigo-900 font-semibold">
                                                        <?php echo e($hasReply ? 'Lihat balasan' : 'Detail'); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="p-6 bg-gray-50 border-t border-gray-200 text-right">
                        <a href="<?php echo e(route('mahasiswa.pengaduan.index')); ?>"
                            class="text-sm font-semibold text-indigo-600 hover:text-indigo-900 transition duration-150 ease-in-out ">
                            Lihat Semua Riwayat Pengaduan &rarr;
                        </a>
                    </div>
                </div>

                <!-- Berita & Pengumuman -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900">Berita & Pengumuman</h3>
                    </div>

                    <div class="divide-y divide-gray-200">
                        <?php if($beritaTerbaru->isEmpty()): ?>
                            <p class="text-gray-500 p-6">Belum ada berita terbaru.</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('berita.show', $item)); ?>"
                                   class="block p-6 hover:bg-gray-50 transition duration-150 ease-in-out">
                                    
                                    <div class="flex items-center space-x-4">
                                        
                                        <div class="flex-shrink-0">
                                            <?php if($item->gambar_berita): ?>
                                                <img class="h-16 w-16 rounded-lg object-cover shadow-sm" 
                                                     src="<?php echo e(asset('storage/' . $item->gambar_berita)); ?>" 
                                                     alt="<?php echo e($item->judul_berita); ?>"> 
                                            <?php else: ?>
                                                <div class="h-16 w-16 rounded-lg bg-gray-200 flex items-center justify-center text-gray-400">
                                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="flex-1 min-w-0">
                                            <h4 class="font-semibold text-blue-600 hover:text-blue-800 truncate">
                                                <?php echo e($item->judul_berita); ?> 
                                            </h4>
                                            
                                            <p class="text-sm text-gray-500 mt-1 line-clamp-2">
                                                <?php echo e(Str::limit($item->isi, 100)); ?>

                                            </p>
                                            
                                            <span class="text-xs text-gray-400 block mt-2">
                                                <?php echo e(\Carbon\Carbon::parse($item->created_at)->locale('id')->diffForHumans()); ?>

                                            </span>
                                        </div>

                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="p-6 bg-gray-50 border-t border-gray-200 text-right">
                        <a href="<?php echo e(route('berita.index')); ?>"
                           class="text-sm font-semibold text-indigo-600 hover:text-indigo-900 transition duration-150 ease-in-out">
                            Lihat Semua Berita &rarr;
                        </a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\studi_kasus_pbl\resources\views/pages/mahasiswa/dashboard.blade.php ENDPATH**/ ?>