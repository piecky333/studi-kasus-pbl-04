<?php $__env->startSection('detail_content'); ?>

<div class="bg-white rounded-lg">
    
    
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 text-sm font-semibold" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm font-semibold" role="alert">
            <?php echo e(session('error')); ?>

            
        </div>
    <?php endif; ?>

            
            
            <h4 class="text-lg font-bold text-gray-800 mb-3 flex items-center mt-4">
                Hasil Perangkingan Akhir
            </h4>
            <p class="text-sm text-gray-600 mb-4">Urutan peringkat alternatif berdasarkan nilai total preferensi (Vi) tertinggi ke terendah.</p>
            
            <div class="overflow-x-auto border border-gray-200 rounded-lg mb-8 shadow-sm">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-bold text-gray-600 uppercase tracking-wider">Nama Alternatif</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-gray-600 uppercase tracking-wider w-32">Peringkat</th>
                            <th class="px-6 py-4 text-center text-xs font-bold text-indigo-700 uppercase tracking-wider w-40">Nilai Akhir (Vi)</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $calculationData['ranking_results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rankResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration > 5): ?> <?php break; ?> <?php endif; ?>
                            <?php
                                $isWinner = $rankResult['rank'] == 1;
                                $isTop3 = $rankResult['rank'] <= 3;
                            ?>
                            <tr class="<?php echo e($isWinner ? 'bg-green-50' : 'hover:bg-gray-50'); ?> transition-colors">
                                
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <?php if($isWinner): ?>
                                            <div class="flex-shrink-0 mr-3">
                                                <div class="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                                                    <i class="fas fa-crown text-green-600 text-sm"></i>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div>
                                            <div class="text-sm font-medium <?php echo e($isWinner ? 'text-green-900' : 'text-gray-900'); ?>">
                                                <?php echo e($rankResult['nama']); ?>

                                            </div>
                                            <?php if($isWinner): ?>
                                                <div class="text-xs text-green-600">Rekomendasi Utama</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>

                                
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <?php if($isWinner): ?>
                                        <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-green-600 text-white font-bold shadow-sm ring-2 ring-green-100">
                                            1
                                        </span>
                                    <?php elseif($isTop3): ?>
                                        <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-gray-600 text-white font-bold shadow-sm">
                                            <?php echo e($rankResult['rank']); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center justify-center h-8 w-8 rounded-full bg-gray-100 text-gray-600 font-bold border border-gray-200">
                                            <?php echo e($rankResult['rank']); ?>

                                        </span>
                                    <?php endif; ?>
                                </td>

                                
                                <td class="px-6 py-4 whitespace-nowrap text-center">
                                    <span class="px-3 py-1 inline-flex text-sm leading-5 font-bold rounded-full <?php echo e($isWinner ? 'bg-green-100 text-green-800' : 'bg-indigo-50 text-indigo-700'); ?> border <?php echo e($isWinner ? 'border-green-200' : 'border-indigo-100'); ?>">
                                        <?php echo e(number_format($rankResult['final_score'], 5)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <hr class="my-8 border-t border-gray-200">

            

            <div class="mb-8">
                <h4 class="font-bold text-gray-800 mb-4 flex items-center">
                    Bobot Kriteria Akhir (Wj)
                </h4>
                <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    <?php $__currentLoopData = $calculationData['criteria_metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $kode = $kriteria->kode_kriteria;
                            $bobot = $calculationData['weights'][$kode] ?? 0;
                            $isBenefit = $kriteria->jenis_kriteria == 'Benefit';
                        ?>
                        <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-4 transition duration-300 hover:shadow-md relative overflow-hidden group">
                            <div class="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                                <i class="fas <?php echo e($isBenefit ? 'fa-arrow-up text-green-500' : 'fa-arrow-down text-red-500'); ?> text-3xl"></i>
                            </div>
                            <div class="relative z-10">
                                <div class="flex justify-between items-start mb-2">
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium <?php echo e($isBenefit ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                        <?php echo e($kode); ?>

                                    </span>
                                </div>
                                <p class="text-xs text-gray-500 h-8 line-clamp-2 leading-tight mb-1" title="<?php echo e($kriteria->nama_kriteria); ?>">
                                    <?php echo e($kriteria->nama_kriteria); ?>

                                </p>
                                <p class="text-xl font-bold text-gray-800">
                                    <?php echo e(number_format($bobot, 4)); ?>

                                </p>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        
        
        <h4 class="text-lg font-bold text-gray-800 mb-3">1. Matriks Keputusan Mentah (Xij)</h4>
        <p class="text-sm text-gray-600 mb-3">Nilai mentah yang diinput: Alternatif vs Kriteria.</p>
        <div class="overflow-x-auto border rounded-lg mb-8">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-600 uppercase tracking-wider border-r">Alternatif</th>
                        <?php $__currentLoopData = $calculationData['criteria_metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-3 py-2 text-center text-xs font-medium text-gray-600 uppercase tracking-wider" title="Jenis: <?php echo e($k->jenis_kriteria); ?>">
                                <?php echo e($k->kode_kriteria); ?>

                                <br><span class="font-normal text-xs italic">(<?php echo e($k->jenis_kriteria); ?>)</span>
                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $calculationData['raw_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rawAlt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900 bg-gray-50 border-r"><?php echo e($rawAlt['nama']); ?></td>
                            <?php $__currentLoopData = $calculationData['criteria_metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono">
                                    <?php echo e($rawAlt[$k->kode_kriteria]); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        <h4 class="text-lg font-bold text-gray-800 mb-3">2. Matriks Normalisasi (Rij)</h4>
        <p class="text-sm text-gray-600 mb-3">Matriks yang sudah dinormalisasi berdasarkan jenis kriteria (Benefit/Cost).</p>
        <div class="overflow-x-auto border rounded-lg mb-8">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-3 py-2 text-left text-xs font-medium text-gray-600 uppercase tracking-wider border-r">Alternatif</th>
                        <?php $__currentLoopData = $calculationData['criteria_metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-3 py-2 text-center text-xs font-medium text-gray-600 uppercase tracking-wider">
                                <?php echo e($k->kode_kriteria); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-3 py-2 text-center text-xs font-bold text-gray-700 uppercase tracking-wider border-l">Vi (Total Preferensi)</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $calculationData['ranking_results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rankResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isBest = $rankResult['rank'] == 1;
                        ?>
                        <tr class="<?php echo e($isBest ? 'bg-yellow-50' : ''); ?>">
                            <td class="px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900 <?php echo e($isBest ? 'bg-yellow-100 font-bold' : 'bg-gray-50'); ?> border-r">
                                <?php echo e($rankResult['nama']); ?>

                            </td>
                            <?php $__currentLoopData = $calculationData['criteria_metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-mono">
                                    <?php echo e(number_format($rankResult['rij_data'][$k->kode_kriteria] ?? 0, 4)); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td class="px-3 py-2 whitespace-nowrap text-sm text-center font-bold font-mono <?php echo e($isBest ? 'text-indigo-800' : 'text-gray-800'); ?> border-l">
                                <?php echo e(number_format($rankResult['final_score'], 4)); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.admin.spk.detail_base', ['currentTab' => 'hasil', 'idKeputusan' => $idKeputusan, 'keputusan' => $keputusan], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\studi_kasus_pbl\resources\views/pages/admin/spk/hasil/index.blade.php ENDPATH**/ ?>