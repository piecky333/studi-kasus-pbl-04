<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('img/Logo hima.png')); ?>" type="image/png">

    <title><?php echo $__env->yieldContent('title', 'Sistem Hima'); ?> - Himpunan Mahasiswa</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts & Styles (Menggunakan Vite seperti Breeze) -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?> 

    
    <?php echo $__env->yieldPushContent('styles'); ?>

    

</head>
<body class="font-sans antialiased bg-gray-100 flex flex-col min-h-screen">

    
    <?php echo $__env->make('partials.user.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if (! empty(trim($__env->yieldContent('hero')))): ?>
        <?php echo $__env->yieldContent('hero'); ?>
    <?php endif; ?>
    
    
    <main class="flex-grow">
        <div class="<?php if (! empty(trim($__env->yieldContent('hero')))): ?> <?php else: ?> mt-16 <?php endif; ?>"> 
             <?php echo e($slot); ?>

        </div>
    </main>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\studi_kasus_pbl\resources\views/layouts/app.blade.php ENDPATH**/ ?>