<style>
    @media (max-width: 767.98px) {
        #accordionSidebar {
            display: none !important;
        }
    }
    @media (min-width: 768px) {
        #accordionSidebar {
            display: flex !important;
            flex-direction: column !important;
            width: 14rem !important;
        }
    }
</style>
<ul class="navbar-nav bg-[#0d2149] sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('pengurus.dashboard')); ?>">
        <div class="sidebar-brand-icon">
            <i class="bi bi-people-fill"></i>
        </div>
        <div class="sidebar-brand-text mx-3">PENGURUS</div>
    </a>

    <hr class="sidebar-divider my-0">

    <!-- Dashboard -->
    <li class="nav-item <?php echo e(request()->is('pengurus/dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('pengurus.dashboard')); ?>">
            <i class="bi bi-speedometer2"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    <!-- Manajemen Data -->
    <div class="sidebar-heading text-light small">Manajemen Data</div>

    <!-- Kelola Divisi -->
    <li class="nav-item <?php echo e(request()->is('pengurus/divisi*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('pengurus.divisi.index')); ?>">
            <i class="bi bi-diagram-3"></i>
            <span>Kelola Divisi</span>
        </a>
    </li>

    <!-- Kelola Jabatan -->
<li class="nav-item <?php echo e(request()->is('pengurus/jabatan*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pengurus.jabatan.index')); ?>">
        <i class="bi bi-person-badge"></i>
        <span>Kelola Jabatan</span>
    </a>
</li>


   <!-- Kelola Pengurus -->
<li class="nav-item <?php echo e(request()->is('pengurus/pengurus*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pengurus.pengurus.index')); ?>">
        <i class="bi bi-people"></i>
        <span>Kelola Pengurus</span>
    </a>
</li>

<li class="nav-item <?php echo e(request()->is('pengurus/berita*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pengurus.berita.index')); ?>">
        <i class="bi bi-newspaper"></i>
        <span>Kelola Berita</span>
    </a>
</li>

<!-- Kelola Prestasi -->
<li class="nav-item <?php echo e(request()->is('pengurus/prestasi*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('pengurus.prestasi.index')); ?>">
        <i class="bi bi-trophy"></i>
        <span>Kelola Prestasi</span>
    </a>
</li>


    <hr class="sidebar-divider">

    <!-- Kembali ke Website -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
            <i class="bi bi-house-door"></i>
            <span>Kembali ke Website</span>
        </a>
    </li>

</ul><?php /**PATH C:\studi_kasus_pbl\resources\views/partials/pengurus/sidebar.blade.php ENDPATH**/ ?>