<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Slot Header -->
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl text-indigo-700 leading-tight tracking-wide">
            <?php echo e(__('Detail Pengaduan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10 bg-gradient-to-br from-gray-100 to-gray-200">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white/80 backdrop-blur-sm shadow-lg sm:rounded-xl border border-gray-100">
                <div class="p-8">

                    <!-- Header Detail -->
                    <div class="border-b border-gray-300 pb-5 mb-6">
                        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">

                            <div>
                                <p class="text-sm font-semibold text-indigo-600 uppercase tracking-wide">
                                    <?php echo e($pengaduan->jenis_kasus); ?>

                                </p>

                                <h3 class="text-3xl font-bold text-gray-900 mt-1">
                                    <?php echo e($pengaduan->judul); ?>

                                </h3>

                                <p class="mt-2 text-sm text-gray-600">
                                    Dilaporkan oleh: 
                                    <strong class="text-gray-800"><?php echo e($pengaduan->user->nama); ?></strong>
                                </p>
                            </div>

                            <div>
                                <?php if($pengaduan->status == 'Diproses'): ?>
                                    <span class="px-4 py-1 rounded-full bg-yellow-200 text-yellow-900 font-semibold shadow-sm">
                                        Diproses
                                    </span>
                                <?php elseif($pengaduan->status == 'Selesai'): ?>
                                    <span class="px-4 py-1 rounded-full bg-green-200 text-green-900 font-semibold shadow-sm">
                                        Selesai
                                    </span>
                                <?php elseif($pengaduan->status == 'Ditolak'): ?>
                                    <span class="px-4 py-1 rounded-full bg-red-200 text-red-900 font-semibold shadow-sm">
                                        Ditolak
                                    </span>
                                <?php else: ?>
                                    <span class="px-4 py-1 rounded-full bg-blue-200 text-blue-900 font-semibold shadow-sm">
                                        Terkirim
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- KONTEN -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-10">

                        <!-- Kiri -->
                        <div class="md:col-span-2 space-y-8">

                            <!-- Deskripsi -->
                            <div>
                                <h4 class="text-xl font-semibold text-gray-800 mb-3">
                                    Deskripsi Kronologi
                                </h4>

                                <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-gray-700 shadow-sm leading-relaxed">
                                    <?php echo nl2br(e($pengaduan->deskripsi)); ?>

                                </div>
                            </div>

                            <!-- Bukti Foto -->
                            <div>
                                <h4 class="text-xl font-semibold text-gray-800 mb-3">
                                    Bukti Foto / Lampiran
                                </h4>

                                <?php if($pengaduan->gambar_bukti): ?>
                                    <div class="group max-w-xs rounded-lg overflow-hidden shadow-md border border-gray-200 bg-white cursor-pointer"
                                         onclick="openModal('<?php echo e(asset('storage/' . $pengaduan->gambar_bukti)); ?>')">

                                        <img src="<?php echo e(asset('storage/' . $pengaduan->gambar_bukti)); ?>"
                                             class="w-full h-48 object-cover group-hover:scale-105 transition duration-300">
                                    </div>

                                    <button onclick="openModal('<?php echo e(asset('storage/' . $pengaduan->gambar_bukti)); ?>')"
                                            class="mt-3 text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                                        Lihat Ukuran Penuh
                                    </button>

                                <?php else: ?>
                                    <div class="flex items-center justify-center h-32 bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg">
                                        <span class="text-gray-500 italic">Tidak ada bukti lampiran</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <!-- Kanan -->
                        <div class="md:col-span-1">
                            <div class="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
                                <h4 class="text-lg font-semibold text-gray-800 mb-4">Informasi Laporan</h4>

                                <dl class="space-y-3 text-gray-700">
                                    <div class="flex justify-between">
                                        <dt class="font-medium">ID Laporan:</dt>
                                        <dd>#<?php echo e($pengaduan->id_pengaduan); ?></dd>
                                    </div>

                                    <div class="flex justify-between">
                                        <dt class="font-medium">Tanggal Dibuat:</dt>
                                        <dd><?php echo e($pengaduan->created_at->format('d F Y, H:i')); ?></dd>
                                    </div>

                                    <div class="flex justify-between">
                                        <dt class="font-medium">Status:</dt>
                                        <dd class="font-semibold"><?php echo e($pengaduan->status); ?></dd>
                                    </div>

                                    <?php if($pengaduan->no_telpon_dihubungi): ?>
                                    <div class="flex justify-between border-t border-gray-100 pt-2 mt-2">
                                        <dt class="font-medium text-gray-900">Kontak:</dt>
                                        <dd class="text-indigo-600 font-mono text-xs font-bold"><?php echo e($pengaduan->no_telpon_dihubungi); ?></dd>
                                    </div>
                                    <?php endif; ?>
                                </dl>
                            </div>
                        </div>

                    </div>

                    <!-- BAGIAN: Diskusi & Tanggapan -->
                    <div class="mt-10">
                        <h4 class="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                            <i class="fas fa-comments text-indigo-600 mr-2"></i> Diskusi & Tanggapan
                        </h4>

                        <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 h-96 overflow-y-auto mb-4 custom-scrollbar flex flex-col space-y-4">
                            <?php $__empty_1 = true; $__currentLoopData = $pengaduan->tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $isUser = $chat->id_user == Auth::id(); // Cek jika chat ini dari user sendiri
                                ?>
                                <div class="flex <?php echo e($isUser ? 'justify-end' : 'justify-start'); ?>">
                                    <div class="flex items-end max-w-[80%] <?php echo e($isUser ? 'flex-row-reverse' : 'flex-row'); ?>">
                                        <!-- Avatar -->
                                        <div class="flex-shrink-0 h-8 w-8 rounded-full overflow-hidden border border-gray-300 <?php echo e($isUser ? 'ml-2' : 'mr-2'); ?>">
                                            <?php if($isUser): ?>
                                                <img src="<?php echo e(Auth::user()->profile_photo_url); ?>" class="h-full w-full object-cover">
                                            <?php else: ?>
                                                 <!-- Admin Avatar Placeholder -->
                                                <img src="https://ui-avatars.com/api/?name=Admin&background=0D2149&color=fff" class="h-full w-full object-cover">
                                            <?php endif; ?>
                                        </div>

                                        <!-- Bubble -->
                                        <div class="px-4 py-2 rounded-lg shadow-sm text-sm <?php echo e($isUser ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white text-gray-800 border border-gray-200 rounded-bl-none'); ?>">
                                            <p><?php echo e($chat->isi_tanggapan); ?></p>
                                            <span class="text-[10px] <?php echo e($isUser ? 'text-indigo-200' : 'text-gray-400'); ?> block mt-1 text-right">
                                                <?php echo e($chat->created_at->format('d M H:i')); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="flex flex-col items-center justify-center h-full text-gray-400">
                                    <i class="fas fa-comment-slash text-4xl mb-2"></i>
                                    <p class="text-sm">Belum ada tanggapan.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Form Balas -->
                        <form action="<?php echo e(route('user.pengaduan.tanggapan', $pengaduan->id_pengaduan)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="flex gap-2">
                                <input type="text" name="isi_tanggapan" required placeholder="Tulis balasan..." 
                                       class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                                <button type="submit" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                    <i class="fas fa-paper-plane mr-2"></i> Kirim
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Tombol -->
                    <div class="border-t border-gray-300 mt-10 pt-5 flex justify-end">
                        <a href="<?php echo e(url()->previous()); ?>"
                           class="px-6 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium rounded-lg shadow-md transition">
                            Kembali
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- MODAL GAMBAR -->
    <div id="imgModal" class="fixed inset-0 bg-black bg-opacity-80 hidden items-center justify-center z-50">
        <div class="relative bg-white p-4 rounded-lg shadow-2xl max-w-4xl mx-auto animate-fadeIn">

            <!-- Close -->
            <button onclick="closeModal()" 
                class="absolute -top-4 -right-4 bg-red-600 text-white w-9 h-9 rounded-full shadow-lg text-lg font-bold">
                ✕
            </button>

            <img id="modalImage" src="" class="max-w-full max-h-[80vh] rounded-lg shadow">

            <div class="text-center mt-4">
                <button onclick="closeModal()" 
                    class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-md text-sm">
                    Kembali ke Halaman Detail
                </button>
            </div>

        </div>
    </div>

    <script>
        function openModal(imageUrl) {
            document.getElementById('modalImage').src = imageUrl;
            document.getElementById('imgModal').classList.remove('hidden');
            document.getElementById('imgModal').classList.add('flex');
        }

        function closeModal() {
            document.getElementById('imgModal').classList.add('hidden');
        }
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\studi_kasus_pbl\resources\views/pages/user/pengaduan/show.blade.php ENDPATH**/ ?>