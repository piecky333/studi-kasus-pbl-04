<?php $__env->startSection('title', $berita->judul_berita); ?>

<?php $__env->startSection('hero'); ?>
    
    <section id="berita-hero" class="relative w-full overflow-hidden" style="height: 70vh;"> 
        
        
        <a href="javascript:void(0)" onclick="openLightbox('<?php echo e(asset('storage/' . $berita->gambar_berita)); ?>')" 
           class="absolute inset-0 block cursor-pointer transition duration-300 hover:opacity-90">
            
            
            <img src="<?php echo e(asset('storage/' . $berita->gambar_berita)); ?>" alt="<?php echo e($berita->judul_berita); ?>" 
                 class="w-full h-full object-cover">
        </a>
             
        
        <div class="absolute inset-0 bg-black bg-opacity-30 pointer-events-none"></div>
    </section>
<?php $__env->stopSection(); ?>

---


<?php $__env->startSection('content'); ?>

    
    <section id="berita-detail" class="py-16 sm:py-20 bg-gray-50 relative transform -translate-y-24 z-10">
        <div class="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">

                
                <div class="lg:col-span-2 bg-white p-6 sm:p-8 rounded-2xl shadow-xl"> 

                    
                    <div class="flex items-center text-sm text-gray-500 mb-6">
                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                            class="w-5 h-5 mr-1.5">
                            <path fill-rule="evenodd"
                                d="M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-5.5-2.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM10 12a5.99 5.99 0 0 0-4.793 2.39A6.483 6.483 0 0 0 10 16.5a6.483 6.483 0 0 0 4.793-2.11A5.99 5.99 0 0 0 10 12Z"
                                clip-rule="evenodd" />
                        </svg>
                        Oleh <strong class="ml-1"><?php echo e($berita->user->name ?? 'Admin HIMA-TI'); ?></strong>
                    </div>

                    <article class="prose prose-lg max-w-none text-gray-700 leading-relaxed">
                        <?php echo $berita->isi_berita; ?>

                    </article>

                    <hr class="my-10">

                    
                    
                    <div id="komentar" class="mt-12">
                        <h2 class="text-2xl font-bold text-blue-800 mb-6">Komentar (<?php echo e($berita->komentar->count()); ?>)</h2>

                        
                        <form action="<?php echo e(route('komentar.store', $berita->id_berita)); ?>" method="POST" class="mb-8">
                            <?php echo csrf_field(); ?>
                            <?php if(session('success')): ?>
                                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-4"
                                    role="alert">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="flex space-x-4">
                                <div class="flex-shrink-0">
                                    <span
                                        class="inline-flex items-center justify-center h-10 w-10 rounded-full bg-gray-200 text-gray-600 font-semibold">
                                        <?php if(auth()->guard()->check()): ?> <?php echo e(substr(Auth::user()->nama, 0, 1)); ?> <?php else: ?> ? <?php endif; ?>
                                    </span>
                                </div>
                                <div class="flex-1">
                                    <?php if(auth()->guard()->guest()): ?>
                                        <div class="mb-2">
                                            <label for="nama_komentator" class="sr-only">Nama Anda</label>
                                            <input type="text" name="nama_komentator" id="nama_komentator" required
                                                class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                                placeholder="Tulis nama Anda..." value="<?php echo e(old('nama_komentator')); ?>">
                                            <?php $__errorArgs = ['nama_komentator'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <label for="isi" class="sr-only">Komentar Anda</label>
                                        <textarea name="isi" id="isi" rows="3" required
                                            class="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                            placeholder="Tulis komentar Anda..."><?php echo e(old('isi')); ?></textarea>
                                        <?php $__errorArgs = ['isi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm mt-1"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="text-right mt-3">
                                        <button type="submit"
                                            class="inline-flex items-center px-6 py-2 bg-blue-700 border border-transparent rounded-lg font-semibold text-white hover:bg-blue-800 transition">
                                            Kirim Komentar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        
                        <div class="space-y-8">
                            <?php $__empty_1 = true; $__currentLoopData = $komentar_induk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('pages.public.partials._komentar', ['komen' => $komen], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500 text-center pt-4">Belum ada komentar. Jadilah yang pertama!</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <aside class="lg:col-span-1">
                    <div class="sticky top-24 p-6 bg-white rounded-2xl shadow-xl">
                        <h3 class="text-xl font-bold text-blue-800 mb-4">Beberapa Prestasi yang mungkin anda tertarik</h3>
                        <div class="space-y-4">
                            <?php $__empty_1 = true; $__currentLoopData = $beritaTerkait; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terkait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="flex space-x-3 group">
                                    <img src="<?php echo e(asset('storage/' . $terkait->gambar_berita)); ?>"
                                        alt="<?php echo e($terkait->judul_berita); ?>"
                                        class="w-20 h-20 rounded-lg object-cover flex-shrink-0">
                                    <div>
                                        <h4 class="font-semibold text-gray-800 group-hover:text-blue-700 leading-tight">
                                            
                                            <a href="<?php echo e(route('prestasi.show', $terkait->id_berita)); ?>"><?php echo e(Str::limit($terkait->judul_berita, 50)); ?></a>
                                        </h4>
                                        <span class="text-xs text-gray-500"><?php echo e($terkait->created_at->format('d M Y')); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500">Tidak ada Prestasi terkait.</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="mt-8 pt-6 border-t border-gray-200">
                            
                            <a href="<?php echo e(route('prestasi.index')); ?>"
                                class="inline-flex items-center justify-center w-full px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition">
                                
                                Lihat semua prestasi
                            </a>
                        </div>
                    </div>
                </aside>

            </div>
        </div>
    </section>

    
    <div id="lightbox-modal" class="fixed inset-0 bg-black bg-opacity-90 z-[9999] hidden items-center justify-center backdrop-blur-md" onclick="closeLightbox()">
        <div class="relative max-w-full max-h-full p-4" onclick="event.stopPropagation()">
            <img id="lightbox-image" src="" alt="Gambar Penuh" class="max-w-full max-h-screen object-contain">
            <button onclick="closeLightbox()" class="absolute top-4 right-4 text-white text-3xl font-bold p-2 hover:text-gray-400">
                &times;
            </button>
        </div>
    </div>


    <?php $__env->startPush('scripts'); ?>
        <script>
            // FUNGSI JS INI TETAP DIPERLUKAN (Komentar)
            function tampilkanFormBalas(id, namaParent) {
                document.querySelectorAll('[id^="form-balas-"]').forEach(form => {
                    if (form.id !== 'form-balas-' + id) {
                        form.classList.add('hidden');
                    }
                });
                var form = document.getElementById('form-balas-' + id);
                form.classList.toggle('hidden');
                if (!form.classList.contains('hidden')) {
                    var spanNama = document.getElementById('nama-parent-' + id);
                    spanNama.textContent = '@' + namaParent;
                }
            }
            
            // FUNGSI JAVASCRIPT UNTUK LIGHTBOX
            function openLightbox(imageUrl) {
                document.getElementById('lightbox-image').src = imageUrl;
                document.getElementById('lightbox-modal').classList.remove('hidden');
                document.getElementById('lightbox-modal').classList.add('flex');
                document.body.style.overflow = 'hidden'; // Mencegah scrolling
            }

            function closeLightbox() {
                document.getElementById('lightbox-modal').classList.add('hidden');
                document.getElementById('lightbox-modal').classList.remove('flex');
                document.body.style.overflow = 'auto'; // Mengizinkan scrolling lagi
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\studi_kasus_pbl\resources\views/pages/public/prestasi/show.blade.php ENDPATH**/ ?>